import json
from pathlib import Path
from time import perf_counter
from typing import Annotated
from uuid import uuid4

import typer

from macromind.contract.loader import load_frozen_contract
from macromind.errors import ContractIntegrityError, MacroMindError
from macromind.registry.loader import load_registry

app = typer.Typer(no_args_is_help=True, help="MacroMind Phase 1.0–1.2")
contract_app = typer.Typer()
schema_app = typer.Typer()
registry_app = typer.Typer()
app.add_typer(contract_app, name="contract")
app.add_typer(schema_app, name="schema")
app.add_typer(registry_app, name="registry")


def emit(value, err=False):
    typer.echo(
        json.dumps(value, ensure_ascii=True, sort_keys=True, indent=None if err else 2), err=err
    )


def log(operation, start, inputs, outputs, errors, warnings):
    emit(
        {
            "run_id": str(uuid4()),
            "operation": operation,
            "version": "0.1.0",
            "ontology_version": "0.3",
            "input_paths": [str(p) for p in inputs],
            "output_paths": [str(p) for p in outputs],
            "errors": errors,
            "warnings": warnings,
            "duration": round(perf_counter() - start, 6),
        },
        err=True,
    )


@contract_app.command("verify")
def contract_verify(contract_root: Annotated[Path, typer.Option("--contract-root")]):
    start = perf_counter()
    errors, warnings = [], []
    try:
        contract = load_frozen_contract(contract_root)
        report = contract.integrity_report
        warnings = report.warnings
        emit(
            {
                "version": contract.version,
                "status": contract.status,
                "core_count": len(contract.core_objects),
                "boundary_count": len(contract.core_boundaries),
                "semantic_hash": contract.semantic_hash,
                "ERROR": 0,
                "WARNING": len(warnings),
                "PASS": sum(c.severity == "PASS" for c in report.checks),
                "report": report.model_dump(),
            }
        )
    except ContractIntegrityError as exc:
        errors = exc.report.errors
        emit(
            {
                "ERROR": len(errors),
                "WARNING": len(exc.report.warnings),
                "PASS": sum(c.severity == "PASS" for c in exc.report.checks),
                "report": exc.report.model_dump(),
            }
        )
        raise typer.Exit(1) from exc
    finally:
        log("contract.verify", start, [contract_root], [], errors, warnings)


@registry_app.command("verify")
def registry_verify(registry_root: Annotated[Path, typer.Option("--registry-root")]):
    start = perf_counter()
    errors = []
    try:
        bundle = load_registry(registry_root)
        emit(
            {
                "status": "PASS",
                "ontology_version": bundle.ontology_version,
                "core_count": sum(o.kind == "core" for o in bundle.object_types.values()),
                "object_count": len(bundle.object_types),
                "enum_count": len(bundle.enums),
                "relation_count": len(bundle.relations),
            }
        )
    except MacroMindError as exc:
        errors = [str(exc)]
        emit({"status": "ERROR", "errors": errors})
        raise typer.Exit(1) from exc
    finally:
        log("registry.verify", start, [registry_root], [], errors, [])


@schema_app.command("export")
def schema_export(
    contract_root: Annotated[Path, typer.Option("--contract-root")],
    registry_root: Annotated[Path, typer.Option("--registry-root")],
    output_root: Annotated[Path, typer.Option("--output-root")],
):
    start = perf_counter()
    errors, outputs = [], []
    try:
        load_frozen_contract(contract_root)
        bundle = load_registry(registry_root)
        from macromind.schema.auxiliary import AUXILIARY_MODELS
        from macromind.schema.core import CORE_MODELS
        from macromind.schema.export import export_schemas

        if not set(CORE_MODELS) | set(AUXILIARY_MODELS) <= set(bundle.object_types):
            from macromind.errors import RegistryError

            raise RegistryError("Executable model missing from object registry")
        if output_root.resolve().is_relative_to(contract_root.resolve()):
            from macromind.errors import SchemaError

            raise SchemaError("Cannot export inside the frozen contract")
        manifest = export_schemas(output_root)
        outputs = [output_root]
        emit({"status": "PASS", "schema_count": len(manifest["schemas"]), "manifest": manifest})
    except MacroMindError as exc:
        errors = [str(exc)]
        emit({"status": "ERROR", "errors": errors})
        raise typer.Exit(1) from exc
    finally:
        log("schema.export", start, [contract_root, registry_root], outputs, errors, [])


if __name__ == "__main__":
    app()
